# Acutis Types & Domain (React/Vite setup)

## 📂 Folder placement
Place these two folders inside your project's `src/` directory:

```
src/
 ├── assets/
 ├── components/
 ├── data/
 ├── services/
 ├── domain/      <-- add this
 ├── types/       <-- add this
 ├── App.tsx
 └── main.tsx
```

## 🧱 Contents
- `/types`: Pure TypeScript interfaces & enums (Resident, Lookup, Rollup, etc.)
- `/domain`: Business logic (mapping, calculations)

## ⚙️ Usage example
```ts
import { Resident } from "@/types";
import { calculateStepDownEligibility } from "@/domain";

const eligible = calculateStepDownEligibility({
  id: "1",
  residentId: "1",
  weekStart: "2025-10-06",
  weekEnd: "2025-10-12",
  therapySessionsAttended: 5,
  therapySessionsMissed: 0,
  incidentReports: 0,
  cleanTestsAllWeek: true,
  stepDownEligible: false,
  calculatedAt: new Date().toISOString()
});

console.log(eligible); // true
```

## ✅ Integration steps
1. Copy these folders into `/src`.
2. Ensure your imports use absolute paths (update `tsconfig.json` if needed):
   ```json
   {
     "compilerOptions": {
       "baseUrl": "src",
       "paths": { "@/*": ["*"] }
     }
   }
   ```
3. Test with:
   ```bash
   npm run dev
   ```
4. Once verified, you can hand the project to Codex for the Vite → Next.js migration.

That's it — this is pilot-ready scaffolding for Acutis.
